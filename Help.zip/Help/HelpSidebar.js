import React from "react"
import { ListGroup, ListGroupItem } from "reactstrap"
import { Link, useLocation } from "react-router-dom"

const HelpSidebar = () => {
  const location = useLocation()
  const menuItems = [
    { name: "Help", path: "/help" },
    { name: "Help Articles", path: "/help-articles" },
    { name: "Help Categories", path: "/help-categories" },
    { name: "Knowledge Base", path: "/knowledge-base" },
    { name: "Knowledge Base Articles", path: "/knowledge-base-articles" },
    { name: "Knowledge Base Categories", path: "/knowledge-base-categories" },
  ]

  return (
    <ListGroup>
      {menuItems.map((item) => (
        <ListGroupItem
          key={item.path}
          tag={Link}
          to={item.path}
          action
          active={location.pathname === item.path}
        >
          {item.name}
        </ListGroupItem>
      ))}
    </ListGroup>
  )
}

export default HelpSidebar
